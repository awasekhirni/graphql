var express = require('express');
var {graphqlHTTP}= require('express-graphql');
var {buildSchema} = require('graphql');
//GraphQL Schema Definition language
//(GraphQL Interface Definition Language) 
var schema = buildSchema(`
  type Query{
      message:String
  }
`);
//Root Resolver 
var root={
    message:()=>'Hello World! Welcome to GraphQL Server Session!'
}; 
//create an express server and a graphQL endpoint 
var app = express();
app.use('/graphql', graphqlHTTP({
    schema: schema,
    rootValue: root,
    graphiql: true
}));
app.listen(4545,()=>console.log('Express GraphQLServer Now running on localhost:4545/graphql'));