
const {ApolloServer, gql} = require('apollo-server');
//schema = graphql schema definition language 
const typeDefs=gql`
  type Query{
      greeting:String
  }
`;
console.log(typeDefs);
//resolvers
const resolvers={
  Query:{
      greeting: () => 'Hello! Apollo GraphQL World!'     
  }
};

//spin off server 
const server = new ApolloServer({typeDefs, resolvers});
server.listen({port:9191})
   .then(({url})=> console.log(`Server running at ${url}`));
