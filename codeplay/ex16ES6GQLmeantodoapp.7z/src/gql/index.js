import {SchemaComposer} from 'graphql-compose';

import db from '../config/dbconfig';

const schemaComposer = new SchemaComposer();

import {UserQuery} from './schema/user.gqlschema';
import {TaskQuery} from './schema/task.gqlschema';
import {UserMutation} from './resolvers/user.resolver';
import {TaskMutation} from './resolvers/task.resolver';

schemaComposer.Query.addFields({
    ...UserQuery,
    ...TaskQuery,
});

schemaComposer.Mutation.addFields({
    ...UserMutation,
    ...TaskMutation,
}); 

export default schemaComposer.buildSchema();

