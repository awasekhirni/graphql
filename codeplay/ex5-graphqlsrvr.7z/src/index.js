var express = require('express')
var {graphqlHTTP} = require('express-graphql');


var { buildSchema } = require('graphql');
// GraphQL schema
var schema = buildSchema(`
    type Query {
        course(id: Int!): Course
        courses(topic: String): [Course]
    },
    type Course {
        id: Int
        title: String
        author: String
        description: String
        topic: String
        url: String
    }
`);
var coursesData = [{
  "id": 1,
  "title": "Last Holiday",
  "author": "Konstantin Wolfendale",
  "description": "Other phlebitis and thrombosis complicating pregnancy and the puerperium, postpartum condition or complication",
  "topic": "Reactive client-driven synergy",
  "url": "https://uol.com.br/id.json?nulla=integer&sed=pede&vel=justo&enim=lacinia&sit=eget&amet=tincidunt&nunc=eget&viverra=tempus&dapibus=vel&nulla=pede&suscipit=morbi&ligula=porttitor&in=lorem&lacus=id&curabitur=ligula&at=suspendisse&ipsum=ornare&ac=consequat&tellus=lectus&semper=in&interdum=est&mauris=risus&ullamcorper=auctor&purus=sed&sit=tristique&amet=in&nulla=tempus&quisque=sit&arcu=amet&libero=sem&rutrum=fusce&ac=consequat"
}, {
  "id": 2,
  "title": "Messenger: The Story of Joan of Arc, The",
  "author": "Kathye Bevens",
  "description": "Anemia of mother, delivered, with or without mention of antepartum condition",
  "topic": "Monitored client-driven service-desk",
  "url": "http://webeden.co.uk/orci/pede/venenatis/non/sodales/sed/tincidunt.xml?lacus=id&morbi=nisl&quis=venenatis&tortor=lacinia&id=aenean&nulla=sit&ultrices=amet&aliquet=justo&maecenas=morbi&leo=ut&odio=odio&condimentum=cras&id=mi&luctus=pede&nec=malesuada&molestie=in&sed=imperdiet&justo=et&pellentesque=commodo&viverra=vulputate&pede=justo&ac=in&diam=blandit&cras=ultrices&pellentesque=enim&volutpat=lorem&dui=ipsum&maecenas=dolor&tristique=sit&est=amet&et=consectetuer&tempus=adipiscing"
}, {
  "id": 3,
  "title": "Gabrielle",
  "author": "Orelia MacGarrity",
  "description": "Burn [any degree] involving 50-59 percent of body surface with third degree burn, 10-19%",
  "topic": "Synergized eco-centric open architecture",
  "url": "https://ucsd.edu/volutpat/erat/quisque/erat/eros/viverra/eget.aspx?consequat=habitasse&morbi=platea&a=dictumst&ipsum=morbi&integer=vestibulum&a=velit&nibh=id&in=pretium&quis=iaculis&justo=diam&maecenas=erat&rhoncus=fermentum&aliquam=justo&lacus=nec&morbi=condimentum&quis=neque&tortor=sapien&id=placerat&nulla=ante&ultrices=nulla&aliquet=justo&maecenas=aliquam&leo=quis&odio=turpis&condimentum=eget&id=elit&luctus=sodales&nec=scelerisque&molestie=mauris&sed=sit&justo=amet&pellentesque=eros&viverra=suspendisse&pede=accumsan&ac=tortor&diam=quis&cras=turpis&pellentesque=sed&volutpat=ante&dui=vivamus&maecenas=tortor&tristique=duis&est=mattis&et=egestas&tempus=metus&semper=aenean&est=fermentum&quam=donec&pharetra=ut&magna=mauris&ac=eget&consequat=massa&metus=tempor&sapien=convallis&ut=nulla&nunc=neque&vestibulum=libero&ante=convallis&ipsum=eget&primis=eleifend&in=luctus&faucibus=ultricies&orci=eu&luctus=nibh&et=quisque&ultrices=id&posuere=justo&cubilia=sit&curae=amet&mauris=sapien&viverra=dignissim&diam=vestibulum&vitae=vestibulum&quam=ante&suspendisse=ipsum&potenti=primis&nullam=in"
}, {
  "id": 4,
  "title": "Get Thrashed: The Story of Thrash Metal",
  "author": "Deanne Frede",
  "description": "Other postoperative functional disorders",
  "topic": "Automated explicit intranet",
  "url": "http://studiopress.com/est/lacinia/nisi/venenatis/tristique/fusce/congue.xml?amet=mattis&eleifend=odio&pede=donec&libero=vitae&quis=nisi&orci=nam&nullam=ultrices&molestie=libero&nibh=non&in=mattis&lectus=pulvinar&pellentesque=nulla&at=pede&nulla=ullamcorper&suspendisse=augue&potenti=a&cras=suscipit&in=nulla&purus=elit&eu=ac&magna=nulla&vulputate=sed&luctus=vel&cum=enim&sociis=sit&natoque=amet&penatibus=nunc&et=viverra&magnis=dapibus&dis=nulla&parturient=suscipit&montes=ligula&nascetur=in&ridiculus=lacus&mus=curabitur&vivamus=at&vestibulum=ipsum&sagittis=ac&sapien=tellus&cum=semper&sociis=interdum&natoque=mauris&penatibus=ullamcorper&et=purus&magnis=sit&dis=amet&parturient=nulla&montes=quisque&nascetur=arcu&ridiculus=libero&mus=rutrum&etiam=ac"
}, {
  "id": 5,
  "title": "Honey Moon (Honigmond)",
  "author": "Andreas Marquand",
  "description": "Unspecified noninflammatory disorder of vulva and perineum",
  "topic": "Ergonomic client-driven hub",
  "url": "https://squarespace.com/nulla/tempus/vivamus/in/felis.js?libero=suspendisse&convallis=accumsan&eget=tortor&eleifend=quis&luctus=turpis&ultricies=sed&eu=ante&nibh=vivamus&quisque=tortor&id=duis&justo=mattis&sit=egestas&amet=metus&sapien=aenean&dignissim=fermentum&vestibulum=donec&vestibulum=ut&ante=mauris&ipsum=eget&primis=massa&in=tempor&faucibus=convallis&orci=nulla&luctus=neque&et=libero&ultrices=convallis&posuere=eget&cubilia=eleifend&curae=luctus&nulla=ultricies&dapibus=eu&dolor=nibh&vel=quisque&est=id&donec=justo&odio=sit&justo=amet&sollicitudin=sapien&ut=dignissim&suscipit=vestibulum&a=vestibulum&feugiat=ante&et=ipsum&eros=primis&vestibulum=in&ac=faucibus&est=orci&lacinia=luctus&nisi=et&venenatis=ultrices&tristique=posuere&fusce=cubilia&congue=curae&diam=nulla&id=dapibus&ornare=dolor&imperdiet=vel&sapien=est&urna=donec&pretium=odio&nisl=justo&ut=sollicitudin&volutpat=ut&sapien=suscipit"
}];

var getCourse = function(args) { 
    var id = args.id;
    return coursesData.filter(course => {
        return course.id == id;
    })[0];
}
var getCourses = function(args) {
    if (args.topic) {
        var topic = args.topic;
        return coursesData.filter(course => course.topic === topic);
    } else {
        return coursesData;
    }
}
var root = {
    course: getCourse,
    courses: getCourses
};
// Create an express server and a GraphQL endpoint
var app = express();
app.use('/graphql', graphqlHTTP({
    schema: schema,
    rootValue: root,
    graphiql: true
}));

app.listen(9191, () => console.log('Express GraphQL Server Now Running On localhost:9191/graphql'));