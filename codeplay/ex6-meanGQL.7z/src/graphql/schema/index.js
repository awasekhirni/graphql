const {buildSchema}=require("graphql");

module.exports=buildSchema(`

type Product{
    _id:ID!
    category:String!
    maincategory:String!
    taxtarifcode:Int!
    suppliername: String! 
    weightmeasure: String!
    weightunit: String!
    description: String! 
    name: String!
    dateofsale: String! 
    productpicurl: String!
    status: String!
    quantity: Int! 
    uom:String!
    currencycode: String!
    price:Int!
    width:Int! 
    depth:Int! 
    height:Int!
    dimunit:String!
}


input ProductInput{
    category:String!
    maincategory:String!
    taxtarifcode:Int!
    suppliername: String! 
    weightmeasure: String!
    weightunit: String!
    description: String!
    name: String!
    dateofsale: String! 
    productpicurl: String!
    status: String!
    quantity: Int! 
    uom:String!
    currencycode: String!
    price:Int!
    width:Int! 
    depth:Int! 
    height:Int!
    dimunit:String!
}

type Query{
    product(_id:Int!):Product
   
    products:[Product!]
}

type Mutation{
    createProduct(product:ProductInput):Product
}

schema{
    query:Query
    mutation:Mutation
}

`)