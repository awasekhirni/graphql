const Product = require("../../models/product");

module.exports={
 
 products: async() =>{
     try{
         const productsFetched = await Product.find()
         return productsFetched.map(product =>{
             return{
                 ...product._doc,
                 _id:product.id,
                 createdAt: new Date(product._doc.createdAt).toISOString(),
             }
         })
     }catch(error){
         throw error
     }
 },

 createProduct:async args=>{
     try{
         const{
             category, maincategory, taxtarifcode, suppliername, 
    weightmeasure, weightunit,description,name,dateofsale,
    productpicurl,    status,    quantity,
    uom,    currencycode,    price,
    width,    depth,    height,    dimunit
         } = args.product 
         const product = new Product({
             category, maincategory, taxtarifcode, suppliername, 
    weightmeasure, weightunit,description,name,dateofsale,
    productpicurl,    status,    quantity,
    uom,    currencycode,    price,
    width,    depth,    height,    dimunit,
         })
         const newProduct = await product.save()
         return {...newProduct._doc, _id:product.id}
     }catch(error){
         throw error
     }
 },

}