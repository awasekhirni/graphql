const express = require("express");
const {graphqlHTTP} = require("express-graphql");
const graphqlSchema = require("./graphql/schema");
const graphqlResolvers = require("./graphql/resolvers");
const mongoose = require('mongoose');

const app = express();

app.use("/graphql",graphqlHTTP({
    schema: graphqlSchema,
    rootValue:graphqlResolvers,
    graphiql:true,
}));

//mongodb+srv://${dbUser}:${dbPass}servername/${dataBaseName}?retryWrites=true&w=majority;

const uri='mongodb://syed:mongotest@localhost/ex6meangraphqldb';
const options = { useNewUrlParser: true, useUnifiedTopology: true }
mongoose
  .connect(uri, options)
  .then(() => app.listen(9191, console.log("MongoDB is Connected +Server is running")))
  .catch(error => {
    throw error
  })