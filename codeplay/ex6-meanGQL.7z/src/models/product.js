const mongoose = require("mongoose");

const Schema = mongoose.Schema 

const productSchema = new Schema({
        category:{
            type:String,
            required:true,
        },
        maincategory:{
            type: String,
            required:true,
        },
        taxtarifcode:{
            type: Number,
            required:true,
        },
        suppliername:{
            type: String,
            required:true,
        },
        weightmeasure:{
            type: String,
            required:true,
        },
        weightunit:{
            type:String,
            required:true,
        },
        description:{
            type:String,
            required:true,
        },
        name:{
            type:String,
            required:true,
        },
        dateofsale:{
            type:String,
            required:true,
        },
        productpicurl:{
            type:String,
            required:true,
        },
        status:{
            type:String,
            required:true,
        },
        quantity:{
            type:Number,
            required:true,
        },
        uom:{
            type:String,
            required:true,
        },
        currencycode:{
            type:String,
            required:true,
        },
        price:{
            type:Number,
            required:true,
        },
        width:{
            type:Number,
            required:true,
        },
        depth:{
            type:Number,
            required:true,
        },
        height:{
            type:String,
            required:true,
        },
        dimunit:{
            type:String,
            required:true,
        }

    },
    {timestamps:true}
);

module.exports = mongoose.model("Product",productSchema);