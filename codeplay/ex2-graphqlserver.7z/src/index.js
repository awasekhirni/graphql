//src/index.js 
var express = require('express');
var {graphqlHTTP}= require('express-graphql');
var {buildSchema}= require('graphql');

//graphql schema
var schema= buildSchema(`
type Query{
    product(id:Int!):Product
    products(name:String):[Product]
},
type Mutation{
    updateProduct(id:Int!, name:String!):Product
}
type Product{
    id:Int 
    category:String
    maincategory:String
    taxtarifcode:Int
    suppliername: String 
    weightmeasure: Float
    weightunit: String
    description: String 
    name: String
    dateofsale: String 
    productpicurl: String
    status: String
    quantity: Int 
    uom:String
    currencycode: String
    price:Int
    width:Int 
    depth:Int 
    height:Int
    dimunit:String
}
`);


var productsData=[
{
"id": 1001,
"category": "laptops",
"maincategory": "computer systems",
"taxtarifcode": 1,
"suppliername": "very best screens",
"weightmeasure": 4.2,
"weightunit": "kg",
"description": "notebook basic 15 with 2,80 ghz quad core, 15\" lcd, 4 gb ddr3 ram, 500 gb hard disc, windows 8 pro",
"name": "notebook basic 15",
"dateofsale": "2017-03-26",
"productpicurl": "test-resources/sap/ui/demokit/explored/img/ht-1000.jpg",
"status": "available",
"quantity": 10,
"uom": "pc",
"currencycode": "eur",
"price": 956,
"width": 30,
"depth": 18,
"height": 3,
"dimunit": "cm"
},
{
"id": 1001,
"category": "laptops",
"maincategory": "computer systems",
"taxtarifcode": 1,
"suppliername": "very best screens",
"weightmeasure": 4.5,
"weightunit": "kg",
"description": "notebook basic 17 with 2,80 ghz quad core, 17\" lcd, 4 gb ddr3 ram, 500 gb hard disc, windows 8 pro",
"name": "notebook basic 17",
"dateofsale": "2017-04-17",
"productpicurl": "test-resources/sap/ui/demokit/explored/img/ht-1001.jpg",
"status": "available",
"quantity": 20,
"uom": "pc",
"currencycode": "eur",
"price": 1249,
"width": 29,
"depth": 17,
"height": 3.1,
"dimunit": "cm"
},
{
"id": 1002,
"category": "laptops",
"maincategory": "computer systems",
"taxtarifcode": 1,
"suppliername": "very best screens",
"weightmeasure": 4.2,
"weightunit": "kg",
"description": "notebook basic 18 with 2,80 ghz quad core, 18\" lcd, 8 gb ddr3 ram, 1000 gb hard disc, windows 8 pro",
"name": "notebook basic 18",
"dateofsale": "2017-01-07",
"productpicurl": "test-resources/sap/ui/demokit/explored/img/ht-1002.jpg",
"status": "available",
"quantity": 10,
"uom": "pc",
"currencycode": "eur",
"price": 1570,
"width": 28,
"depth": 19,
"height": 2.5,
"dimunit": "cm"
}];


var getProduct = function(args){
    var id=args.id;
    return productsData.filter(product =>{
        return product.id ==id;
    })[0];
}

var getProducts= function(args){
    if(args.topic){
        var name=args.name;
        return productsData.filter(product=>product.name===name);
    }else{
        return productsData;
    }
}


var updateProductName = function({id,name}){
    productsData.map(product=>{
        if(product.id===id){
            product.name=name;
            return name;
        }
    });
    return productsData.filter(product => product.id===id)[0];
}


//Root Resolver --- mapping function to endpoints
var root = {
    product:getProduct,
    products:getProducts,
    updateProductName:updateProductName
};

var app = express();

app.use(
    "/graphql",
    graphqlHTTP({
        schema:schema,
        rootValue:root,
        graphiql:true,
    })
);

app.listen(4545);
console.log("Running a GraphQL API server at localhost:4545/graphql");
