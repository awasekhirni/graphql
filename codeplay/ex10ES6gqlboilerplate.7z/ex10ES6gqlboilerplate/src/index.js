import {GraphQLServer, PubSub} from 'graphql-yoga'
import db from './config/dbconfig'

import dotenv from 'dotenv'
import {typeDefs} from "./graphql/schema/schema.graphql"
import {resolvers} from './graphql/resolvers/index'

const pubsub= new PubSub()

dotenv.config()

const server = new GraphQLServer({
    typeDefs,
    resolvers,
    context:{
        db,
        pubsub
    }
});

const options={
    port:process.env.PORT || 9494,
    endpoint: '/graphql',
    subscription:'/subscriptions',
    playground:'/playground',
}


server.start(options,({port})=> console.log('GraphQL Server is running on port ${port}'))



