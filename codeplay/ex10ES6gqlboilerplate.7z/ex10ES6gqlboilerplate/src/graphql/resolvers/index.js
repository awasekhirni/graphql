
export const resolvers={
    Query:{
        welcomemsg:()=>"Welcome"
    }
}