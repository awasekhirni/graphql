import mongoose from 'mongoose';

mongoose.connect('mongodb://syed:mongotest@localhost:27017/ex10gqlboilerplatedb',
     {useNewUrlParser:true, 
     useUnifiedTopology:true})
     .then(db => console.log('Connection to MongoDB has been Successful!'))
     .catch(err => console.log(err));

