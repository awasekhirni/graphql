const {gql} =require("apollo-server");

const typeDefs = gql`
 type Query{
    product(id:Int!):Product
    products:[Product]
}

type Mutation{
    createProduct(product:ProductInput):Product
}

type Product{
    id:Int 
    category:String
    maincategory:String
    taxtarifcode:Int
    suppliername: String 
    weightmeasure: Float
    weightunit: String
    description: String 
    name: String
    dateofsale: String 
    productpicurl: String
    status: String
    quantity: Int 
    uom:String
    currencycode: String
    price:Int
    width:Int 
    depth:Int 
    height:Int
    dimunit:String
}

input ProductInput{
    category:String
    maincategory:String
    taxtarifcode:Int
    suppliername: String 
    weightmeasure: Float
    weightunit: String
    description: String 
    name: String
    dateofsale: String 
    productpicurl: String
    status: String
    quantity: Int 
    uom:String
    currencycode: String
    price:Int
    width:Int 
    depth:Int 
    height:Int
    dimunit:String
    
}
`





module.exports = typeDefs;