//resolvers.js

let products=[
{
"id": 1001,
"category": "laptops",
"maincategory": "computer systems",
"taxtarifcode": 1,
"suppliername": "very best screens",
"weightmeasure": 4.2,
"weightunit": "kg",
"description": "notebook basic 15 with 2,80 ghz quad core, 15\" lcd, 4 gb ddr3 ram, 500 gb hard disc, windows 8 pro",
"name": "notebook basic 15",
"dateofsale": "2017-03-26",
"productpicurl": "test-resources/sap/ui/demokit/explored/img/ht-1000.jpg",
"status": "available",
"quantity": 10,
"uom": "pc",
"currencycode": "eur",
"price": 956,
"width": 30,
"depth": 18,
"height": 3,
"dimunit": "cm"
},
{
"id": 1001,
"category": "laptops",
"maincategory": "computer systems",
"taxtarifcode": 1,
"suppliername": "very best screens",
"weightmeasure": 4.5,
"weightunit": "kg",
"description": "notebook basic 17 with 2,80 ghz quad core, 17\" lcd, 4 gb ddr3 ram, 500 gb hard disc, windows 8 pro",
"name": "notebook basic 17",
"dateofsale": "2017-04-17",
"productpicurl": "test-resources/sap/ui/demokit/explored/img/ht-1001.jpg",
"status": "available",
"quantity": 20,
"uom": "pc",
"currencycode": "eur",
"price": 1249,
"width": 29,
"depth": 17,
"height": 3.1,
"dimunit": "cm"
},
{
"id": 1002,
"category": "laptops",
"maincategory": "computer systems",
"taxtarifcode": 1,
"suppliername": "very best screens",
"weightmeasure": 4.2,
"weightunit": "kg",
"description": "notebook basic 18 with 2,80 ghz quad core, 18\" lcd, 8 gb ddr3 ram, 1000 gb hard disc, windows 8 pro",
"name": "notebook basic 18",
"dateofsale": "2017-01-07",
"productpicurl": "test-resources/sap/ui/demokit/explored/img/ht-1002.jpg",
"status": "available",
"quantity": 10,
"uom": "pc",
"currencycode": "eur",
"price": 1570,
"width": 28,
"depth": 19,
"height": 2.5,
"dimunit": "cm"
}];


const getProducts=()=>{
    return Promise.resolve(products);
}

const getProductsById=({
    productId
}) =>{
    return  Promise.resolve(product.find(p=> p.id === productId));

}


createProduct = ({product})=>{
    const newId = products.length===0?1:products[products.length-1].id +1;
    products = [...products,{...products, id:newId}];
    return Promise.resolve('successfully created a new product');
}

module.exports ={
   Query:{
       products:async() => getProducts(),
       product: async(_, {id}) => getProductById({productId:id})
   },
   Mutation:{
       createProduct:async(_, {product})=>createProduct({product})
   }

};