import { GraphQLServer } from 'graphql-yoga'


// demo mock data
const users = [{
    id: '1',
    name: 'Syed Awase Khirni',
    email: 'awase@gmail.com',
    age: 36
}, {
    id: '2',
    name: 'Syed Ameese Sadath',
    email: 'sadath@gmail.com',
    age:32
}, {
    id: '3',
    name: 'Syed Azeez ',
    email: 'azeez@gmail.com',
    age:23
}]

const posts = [{
    id: '1',
    title: 'blog 101',
    body: 'Blog body 101',
    published: true,
    author: '1'
}, {
    id: '2',
    title: 'blog 201',
    body: 'blog body 201',
    published: false,
    author: '2'
}, {
    id: '3',
    title: 'blog 301',
    body: 'blog body 301',
    published: false,
    author: '3'
}]

const comments=[{
    id:"1",
    text:' nice piece!',
    author:'3',
    post:'1'
},
{
    id:"2",
    text:' do not agree with this!',
    author:'2',
    post:'2'
},
{
    id:"3",
    text:' nicely written, but some contradicting statements',
    author:'1',
    post:'1'
}]

// Type definitions (schema)
const typeDefs = `
    type Query {
        users(query: String): [User!]!
        posts(query: String): [Post!]!
        comments: [Comment!]!
        myuser: User!
        post: Post!
    }

    type User {
        id: ID!
        name: String!
        email: String!
        age: Int
        posts:[Post!]!
        comments:[Comment!]!
    }

    type Post {
        id: ID!
        title: String!
        body: String!
        published: Boolean!
        author: User!
        comments : [Comment!]!
    }

    type Comment{
        id:ID!
        text: String!
        author: User!
        post:Post!
    }

`

// Resolvers
const resolvers = {
    Query: {
        users(parent, args, ctx, info) {
            if (!args.query) {
                return users
            }

            return users.filter((user) => {
                return user.name.toLowerCase().includes(args.query.toLowerCase())
            })
        },
        posts(parent, args, ctx, info) {
            if (!args.query) {
                return posts
            }

            return posts.filter((post) => {
                const isTitleMatch = post.title.toLowerCase().includes(args.query.toLowerCase())
                const isBodyMatch = post.body.toLowerCase().includes(args.query.toLowerCase())
                return isTitleMatch || isBodyMatch
            })
        },
        comments(parent, args,ctx,info){
            return comments
        },
        myuser() {
            return {
                id: '32177',
                name: 'Syed Rayyan',
                email: 'rayyan@gmail.com'
            }
        },
        post() {
            return {
                id: '12387',
                title: 'Message 101',
                body: 'Message body 101',
                published: false
            }
        }
    },
    Post: {
        author(parent, args, ctx, info) {
            return users.find((user) => {
                return user.id === parent.author
            })
        },
        comments(parent,args,ctx,info){
            return comments.filter( (user)=> {
                return comment.post === parent.id
            })
        }
    },
    Comment:{
        author(parent,args,ctx,info){
            return users.find( (user)=>{
                return user.id === parent.author
            })
        },
        post(parent,args,ctx,info){
            return posts.find( (post)=>{
                return post.id === parent.post
            })
        }
    },
    User:{
        posts(parent,args,ctx,info){
            return posts.filter( (post)=>{
                return post.author == parent.id
            })
        },
        comments(parent,args,ctx,info){
            return comments.filter( (comment)=>{
                return comment.author === parent.id
            })
        }

    }
}

const server = new GraphQLServer({
    typeDefs,
    resolvers
})

server.start(() => {
    console.log('Graphql yoga server is rendered at http://localhost:4000!')
})